"""
Telegram order-intake bot
--------------------------
Flow:
  1. Ask buyer's name
  2. Ask model's name
  3. Ask model's link
  4. Ask payment status: "Already paid" or "Need to pay"
       -> if "Need to pay": send a real Stripe Checkout link.
          The OWNER manually presses "Confirm Payment" once the money
          has arrived (no webhook needed).
  5. Ask for 5 photos of the model
  6. Ask for 5 videos of the model
  7. Generate a confirmation ticket, send it to the buyer, and forward
     ALL collected info + media to the OWNER's own Telegram chat.

Requirements:
    pip install python-telegram-bot==21.4 stripe python-dotenv

Env vars (put them in a .env file next to this script):
    BOT_TOKEN=123456:ABC...        # from @BotFather
    OWNER_CHAT_ID=111111111        # your own numeric Telegram user id
    STRIPE_API_KEY=sk_live_xxx     # or sk_test_xxx while testing
    STRIPE_PRICE_ID=price_xxx      # a Price object created in your Stripe dashboard
"""

import os
import random
import string
import logging
from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta

from dotenv import load_dotenv
from telegram import (
    Update,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
)
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    CallbackQueryHandler,
    ContextTypes,
    filters,
)

load_dotenv()

BOT_TOKEN = os.environ["BOT_TOKEN"]
OWNER_CHAT_ID = int(os.environ["OWNER_CHAT_ID"])

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)
log = logging.getLogger(__name__)

# ---------------------------------------------------------------------
# In-memory session store: {telegram_user_id: {...}}
# For a single-VPS bot this is fine. Restarting the bot clears sessions.
# ---------------------------------------------------------------------
SESSIONS: dict[int, dict] = {}

# Steps
ASK_NAME = "ASK_NAME"
ASK_MODEL_NAME = "ASK_MODEL_NAME"
ASK_MODEL_LINK = "ASK_MODEL_LINK"
ASK_PAYMENT = "ASK_PAYMENT"
WAIT_PAYMENT_CONFIRM = "WAIT_PAYMENT_CONFIRM"
ASK_PHOTOS = "ASK_PHOTOS"
ASK_VIDEOS = "ASK_VIDEOS"
DONE = "DONE"

REQUIRED_PHOTOS = 5
REQUIRED_VIDEOS = 5


def new_session() -> dict:
    return {
        "step": ASK_NAME,
        "buyer_name": None,
        "model_name": None,
        "model_link": None,
        "paid": False,
        "photos": [],  # list of file_id
        "videos": [],  # list of file_id
    }


def gen_ticket_id() -> str:
    return "ORD-" + "".join(random.choices(string.ascii_uppercase + string.digits, k=8))


# ---------------------------------------------------------------------
# /start
# ---------------------------------------------------------------------
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    SESSIONS[user_id] = new_session()
    await update.message.reply_text(
        "Welcome! Let's set up your order.\n\nWhat is your name?"
    )


# ---------------------------------------------------------------------
# Text messages -> routed by current step
# ---------------------------------------------------------------------
async def handle_text(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    session = SESSIONS.get(user_id)
    if session is None:
        await update.message.reply_text("Send /start to begin.")
        return

    text = update.message.text.strip()
    step = session["step"]

    if step == ASK_NAME:
        session["buyer_name"] = text
        session["step"] = ASK_MODEL_NAME
        await update.message.reply_text("What is the model's name?")

    elif step == ASK_MODEL_NAME:
        session["model_name"] = text
        session["step"] = ASK_MODEL_LINK
        await update.message.reply_text("Please send the link to the model's page.")

    elif step == ASK_MODEL_LINK:
        session["model_link"] = text
        session["step"] = ASK_PAYMENT
        keyboard = InlineKeyboardMarkup(
            [
                [InlineKeyboardButton("✅ Already paid", callback_data="paid_yes")],
                [InlineKeyboardButton("💳 Need to pay", callback_data="paid_no")],
            ]
        )
        await update.message.reply_text(
            "Have you already paid, or do you still need to pay?",
            reply_markup=keyboard,
        )

    elif step == ASK_PHOTOS or step == ASK_VIDEOS:
        await update.message.reply_text(
            "Please upload the media as a photo/video, not as text."
        )

    else:
        await update.message.reply_text("Send /start to begin a new order.")


# ---------------------------------------------------------------------
# Payment choice buttons
# ---------------------------------------------------------------------
async def payment_choice(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user_id = query.from_user.id
    session = SESSIONS.get(user_id)
    if session is None:
        return

    if query.data == "paid_yes":
        session["paid"] = True
        session["step"] = ASK_PHOTOS
        await query.edit_message_text("Payment noted as already made.")
        await context.bot.send_message(
            user_id, f"Please upload {REQUIRED_PHOTOS} photos of the model."
        )

    elif query.data == "paid_no":
        session["step"] = WAIT_PAYMENT_CONFIRM

        await query.edit_message_text(
            "Thanks! Please arrange payment with the owner. "
            "You'll be able to continue as soon as your payment is confirmed."
        )

        # Notify owner with a manual confirm button
        owner_keyboard = InlineKeyboardMarkup(
            [[InlineKeyboardButton("✅ Confirm payment received", callback_data=f"ownerconfirm_{user_id}")]]
        )
        await context.bot.send_message(
            OWNER_CHAT_ID,
            "💳 New order waiting for payment.\n"
            f"Buyer: {session['buyer_name']}\n"
            f"Model: {session['model_name']}\n"
            f"Telegram user id: {user_id}\n\n"
            "Press the button below once you've received the payment.",
            reply_markup=owner_keyboard,
        )


# ---------------------------------------------------------------------
# Owner presses "Confirm payment received"
# ---------------------------------------------------------------------
async def owner_confirm(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    if query.from_user.id != OWNER_CHAT_ID:
        await query.answer("Not authorized.", show_alert=True)
        return

    buyer_id = int(query.data.split("_", 1)[1])
    session = SESSIONS.get(buyer_id)
    if session is None:
        await query.edit_message_text("Session no longer exists.")
        return

    session["paid"] = True
    session["step"] = ASK_PHOTOS
    await query.edit_message_text(query.message.text + "\n\n✅ Confirmed by owner.")

    await context.bot.send_message(
        buyer_id,
        f"Payment confirmed! Please upload {REQUIRED_PHOTOS} photos of the model.",
    )


# ---------------------------------------------------------------------
# Photo / video uploads
# ---------------------------------------------------------------------
async def handle_photo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    session = SESSIONS.get(user_id)
    if session is None or session["step"] != ASK_PHOTOS:
        return

    file_id = update.message.photo[-1].file_id
    session["photos"].append(file_id)
    remaining = REQUIRED_PHOTOS - len(session["photos"])

    if remaining > 0:
        await update.message.reply_text(f"Got it. {remaining} more photo(s) to go.")
    else:
        session["step"] = ASK_VIDEOS
        await update.message.reply_text(
            f"All {REQUIRED_PHOTOS} photos received. Now please upload {REQUIRED_VIDEOS} videos of the model."
        )


async def handle_video(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    session = SESSIONS.get(user_id)
    if session is None or session["step"] != ASK_VIDEOS:
        return

    file_id = update.message.video.file_id
    session["videos"].append(file_id)
    remaining = REQUIRED_VIDEOS - len(session["videos"])

    if remaining > 0:
        await update.message.reply_text(f"Got it. {remaining} more video(s) to go.")
    else:
        await finish_order(update, context, user_id, session)


# ---------------------------------------------------------------------
# Ticket generation + forwarding everything to the owner
# ---------------------------------------------------------------------
async def finish_order(update: Update, context: ContextTypes.DEFAULT_TYPE, user_id: int, session: dict):
    session["step"] = DONE
    ticket_id = gen_ticket_id()
    start_date = datetime.now()
    end_date = start_date + relativedelta(months=1)
    today = start_date.strftime("%d %b %Y")

    ticket_text = (
        "✅ ORDER CONFIRMED\n\n"
        f"Ticket: {ticket_id}\n"
        f"Buyer: {session['buyer_name']}\n"
        f"Model: {session['model_name']}\n"
        f"Model link: {session['model_link']}\n"
        f"Media received: {len(session['photos'])} photos, {len(session['videos'])} videos\n"
        f"Subscription plan: 1 month full daily subs "
        f"({start_date.strftime('%d %b %Y')} → {end_date.strftime('%d %b %Y')})\n\n"
        "Status: 🟢 ACTIVE\n"
        "Traffic will start coming in within the next 24-48 hours.\n\n"
        "Thank you for your order!"
    )
    await update.message.reply_text(ticket_text)

    # --- forward everything to the owner ---
    summary = (
        "📥 New completed order\n\n"
        f"Ticket: {ticket_id}\n"
        f"Buyer: {session['buyer_name']} (telegram id {user_id})\n"
        f"Model: {session['model_name']}\n"
        f"Model link: {session['model_link']}\n"
        f"Paid: {'Yes' if session['paid'] else 'No'}\n"
        f"Subscription plan: 1 month full daily subs "
        f"({start_date.strftime('%d %b %Y')} → {end_date.strftime('%d %b %Y')})\n"
        f"Date: {today}"
    )
    await context.bot.send_message(OWNER_CHAT_ID, summary)

    for file_id in session["photos"]:
        await context.bot.send_photo(OWNER_CHAT_ID, file_id, caption=f"Ticket {ticket_id} - photo")

    for file_id in session["videos"]:
        await context.bot.send_video(OWNER_CHAT_ID, file_id, caption=f"Ticket {ticket_id} - video")

    SESSIONS.pop(user_id, None)


# ---------------------------------------------------------------------
def main():
    app = Application.builder().token(BOT_TOKEN).build()

    app.add_handler(CommandHandler("start", start))
    app.add_handler(CallbackQueryHandler(payment_choice, pattern="^paid_"))
    app.add_handler(CallbackQueryHandler(owner_confirm, pattern="^ownerconfirm_"))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_text))
    app.add_handler(MessageHandler(filters.PHOTO, handle_photo))
    app.add_handler(MessageHandler(filters.VIDEO, handle_video))

    log.info("Bot started.")
    app.run_polling()


if __name__ == "__main__":
    main()
